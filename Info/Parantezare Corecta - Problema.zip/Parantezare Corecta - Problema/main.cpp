#include <bits/stdc++.h>

using namespace std;

ifstream fin("parantezare.in");
ofstream fout("parantezare.out");

string s;

int main()
{
    fin>>s;

    stack <char> q;

    int ok1 = 0; /// {
    int ok2 = 0; /// [
    int ok3 = 0; /// (

    int ans1 = 0;
    int ans2 = 0;
    int ans3 = 0;

    for(auto c:s)
    {
        if( (c<='z' && c>='a') ||
            (c<='Z' && c>='A') ||
            (c<='9' && c>='0'))
            continue;

        if(c=='(')
        {
            q.push(c);
            ++ok3;
            ++ans3;
        }
        else
        if(c==')')
        {
            if(!q.empty() && q.top()=='(')
                q.pop();
            else
            {
                fout<<0;
                return 0;
            }
            --ok3;
        }
        else
        if(c=='[')
        {
            if(ok3)
            {
                fout<<0;
                return 0;
            }
            q.push(c);
            ++ok2;
            ++ans2;
        }
        else
        if(c==']')
        {
            if(!q.empty() && q.top()=='[')
                q.pop();
            else
            {
                fout<<0;
                return 0;
            }
            --ok2;
        }
        else
        if(c=='{')
        {
            if(ok2 || ok3)
            {
                fout<<0;
                return 0;
            }
            q.push(c);
            ++ok1;
            ++ans1;
        }
        else
        if(c=='}')
        {
            if(!q.empty() && q.top()=='{')
                q.pop();
            else
            {
                fout<<0;
                return 0;
            }
            --ok1;
        }
        else
        {
            fout<<0;
            return 0;
        }
    }
    if(!q.empty())
    {
        fout<<0;
        return 0;
    }
    fout<<1<<'\n';
    fout<<ans1<<' '<<ans2<<' '<<ans3;
}
